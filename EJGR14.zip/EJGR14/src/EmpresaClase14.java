class EmpresaClase14 {
    public static void main(String[] args) {
        // Crear instancias de las clases utilizando los constructores y métodos mutadores
        Cliente cliente1 = new Cliente();
        cliente1.setRut(12345678);
        cliente1.setNombres("Juan");
        cliente1.setApellidos("Pérez");
        cliente1.setTelefono("123456789");
        cliente1.setAfp("AFP Provida");
        cliente1.setSistemaSalud(1);
        cliente1.setDireccion("Calle 123");
        cliente1.setComuna("Santiago");
        cliente1.setEdad(30);

        Cliente cliente2 = new Cliente(87654321, "María", "González", "987654321", "AFP Cuprum", 2,
                "Avenida 456", "Viña del Mar", 25);

        Usuario usuario1 = new Usuario();
        usuario1.setNombre("Pedro");
        usuario1.setFechaNacimiento("10/05/1990");
        usuario1.setRun("11111111-1");

        Usuario usuario2 = new Usuario("Ana", "05/02/1985", "22222222-2");

        Capacitacion capacitacion1 = new Capacitacion();
        capacitacion1.setIdentificador(1);
        capacitacion1.setRutCliente(12345678);
        capacitacion1.setDia("16/06/2023");
        capacitacion1.setHora("15:00");
        capacitacion1.setLugar("Sala de conferencias");
        capacitacion1.setDuracion(120);
        capacitacion1.setCantidadAsistentes(50);

        Capacitacion capacitacion2 = new Capacitacion(2, 87654321, "18/06/2023", "10:00", "Auditorio principal",
                90, 100);

        // Desplegar los datos de los objetos utilizando el método toString()
        System.out.println(cliente1.toString());
        System.out.println(cliente2.toString());
        System.out.println(usuario1.toString());
        System.out.println(usuario2.toString());
        System.out.println(capacitacion1.toString());
        System.out.println(capacitacion2.toString());

        // Modificar un atributo a elección de cada clase
        cliente1.setEdad(35);
        usuario1.setNombre("Juan");
        capacitacion1.setDuracion(90);

        // Desplegar los datos de cada objeto utilizando los métodos accesores y otros métodos
        System.out.println("Datos de cliente1:");
        System.out.println("RUT: " + cliente1.getRut());
        System.out.println("Nombre completo: " + cliente1.obtenerNombre());
        System.out.println("Edad: " + cliente1.getEdad());
        System.out.println("Sistema de salud: " + cliente1.obtenerSistemaSalud());

        System.out.println("Datos de usuario1:");
        System.out.println("Nombre: " + usuario1.getNombre());
        System.out.println(usuario1.mostrarEdad());

        System.out.println("Datos de capacitacion1:");
        System.out.println(capacitacion1.mostrarDetalle());
    }
}
